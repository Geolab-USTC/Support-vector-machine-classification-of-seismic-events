#include <stdio.h>
#include <math.h>
#include <string.h>
#include "sac.h"

int main(int argc, char **argv){
  char reference[128];
  SACHEAD hd;
  float f1,f2,f3;
  float* ar;
  int i,j,k,n1,n2,n3,error;
  float sumall,sum1,sum2,sum3;
  float fmax1,fmax2;
  error =0;
  
  /*input parameters*/
  for(i=1;!error && i<argc;i++ ){
    if(argv[i][0] == '-'){
    switch(argv[i][1]){
    case 'R':
    	sscanf(&argv[i][2],"%s",reference);
	break;
	
    case 'D':
    	sscanf(&argv[i][2],"%f/%f/%f",&f1,&f2,&f3);
	break;
    default:
        error = 1;
	break;
    }
    }
  }

  if (argc < 2 || error){
     fprintf(stderr,"Usage:sacSpecRatio -Rspec.sac -Df1/f2/f3 \nGot the weight of certain frequency\n");
return 1;
  }

/*  tmark = -5; b */
  ar = read_sac(reference,&hd);
 
  n1 = rint(f1/hd.delta);
  n2 = rint(f2/hd.delta);
  n3 = rint(f3/hd.delta);

  sumall = 0.0;
  for(i=n1;i<n3;i++){
    sumall += ar[i];
  }
    
  sum1 = 0.0; fmax1 = 0.0;
  for(i=n1;i<n2;i++){
    sum1 += ar[i];
    if(ar[i] > fmax1)fmax1 = ar[i];
  }
  
  sum2 = 0.0;fmax2 = 0.0;
  for(i=n2;i<n3;i++){
    sum2 += ar[i];
    if(ar[i] > fmax2)fmax2 = ar[i];
  }
  
  printf("%s  %.2f %.2f %.2f %.2f\n",reference,sum1/sumall,sum2/sumall,fmax1/fmax2);
}
