1. Data preparation 
You need to prepare the event waveforms that need to be classified. The waveform cuted in SAC includes P wave and S wave in the same trace.
You must write the P-wave first arrival, S-wave arrival, event location, magnitude,origin time of earthquake, and station location into the waveform. 
Please do not perform any other waveform preprocessing, including filter,de-meaned, de-trended and tapered. It will be done in the script "Make_spectra.pl" .

2. Data storage rules 
To avoid modifying the loop called in the program, the waveforms recorded at the same station are stored in a folder named after the station.

3. Program usage instructions for extraction of event discriminant features
You can run the script "Make_spectra.pl" to get the normalized network-averaged spectra of P and S waves (27 AP (f) and 27 AS (f)).
You can run the script 'grid_sta.m' and 'all_event_all_ratio.m' to get the percentage of event daytime occurrence in the file 'The percentage of event daytime occurrence'.

4. A brief introduction to the functions of subprograms called in programs:
'sacRMS' will calculate the signal-to-noise ratio of the data. 
'stacksac' will stack and average P or S spectrum recorded by all the seismic observations of the same event.
'sacSpecmean' will calculate the normalized network-averaged spectra in various narrower frequency range from 1 to 15 HZ.(frequency range in the file 'filter_spectral')

5. Support vector machine classification of seismic events 
We use a support vector machine (SVM) method (Cortes & Vapnik, 1995; Vapnik, 1995) to classify the events. 
For solving the problem, we have chosen to use the LIBSVM package (Chang & Lin, 2011) (Software available at: https://www.csie.ntu.edu.tw/~cjlin/libsvm/),
which is an implementation of Vapnik's SVM method (Vapnik, 1995). 
 
6. References  (Paper published by program providers)
 Tang L, Zhang M, Wen L. 2019. Support vector machine classification of seismic events in Tianshan orogenic belt. J. Geophys. Res. Solid Earth.
 
 Welcome to download my program and cite my article, if you encounter problems, please contact me by email (tll@mail.ustc.edu.cn)