You need to prepare the catalog of repeating earthquakes  and the catalog you are going to classify in your study.

First you can run the script 'grid_sta.m', then you can run the script 'all_event_all_ratio.m', and you will get the the percentage of event daytime occurrence.