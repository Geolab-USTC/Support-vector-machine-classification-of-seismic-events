tic
clear all
clc

doublet=load('Repeating_earthquakes_catlog');
m=size(doublet,1);

lat_double=doublet(:,2);
lon_double=doublet(:,3);

tt=[0 1 2 3 4 5 6 7 8 9 22 23 10 11 12 13 14 15 16 17 18 19 20 21];

lat_min=40;
lat_max=47;
lon_min=79;
lon_max=91;

window=0.3;
step=0.05;

row=(lat_max-lat_min)/step-1;
list=(lon_max-lon_min)/step-1;

x=zeros(list,1);
x1=lon_min;
for i=1:list
    x(i,1)=x1+step*(i-1);
end

y=zeros(row,1);
y1=lat_min;
for i=1:row
    y(i,1)=y1+step*(i-1);
end       
   
   newsydata1=zeros(row*list,5);
   for i=1:row
      for j=1:list
          for t=1:m
              u=list*(i-1)+j;     
              newsydata1(u,1)=x(j)+window/2;
              newsydata1(u,2)=y(i)+window/2;
              if lon_double(t)>=x(j) && lon_double(t)<=x(j)+window && lat_double(t)>=y(i) && lat_double(t)<=y(i)+window               
        time=num2str(doublet(t,1));
        hour=str2num(time(9:10));
        rr1=find(hour==tt(1:12));
        rr2=find(hour==tt(13:24));
        day=0;
        night=0;
        if ~isempty(rr1)
            night=1;
        elseif ~isempty(rr2)
            day=1;
        end
        newsydata1(u,3)=newsydata1(u,3)+day;
        newsydata1(u,4)=newsydata1(u,4)+night;
        newsydata1(u,5)=newsydata1(u,5)+1;
              end   
          end
       end
   end
   
   fid2=fopen('ratio_time_doublet_ratio','wt');
    for i=1:row*list                
        if newsydata1(i,5)>=6
        ratio2=newsydata1(i,3)/newsydata1(i,5);
        elseif newsydata1(i,5)<6
        ratio2=0;    
        end
        if newsydata1(i,1)>0 && newsydata1(i,2)>0
        fprintf(fid2,'%.2f   %.2f   %.2f\n',newsydata1(i,1),newsydata1(i,2),ratio2); 
        end              
    end

   fclose(fid2);
   toc