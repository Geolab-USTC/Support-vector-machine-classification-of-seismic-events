tic
clear all
clc

ratio_time_doublet=load('ratio_time_doublet_ratio');

data=load('catalog');
lat_all=data(:,2);
lon_all=data(:,3);
n=size(data,1);

newsydata=zeros(n,6);
fid=fopen('Daytime_occurrence_ratio','wt'); 
for i=1:n      
        newsydata(i,1)=data(i,1);
        newsydata(i,2)=data(i,2);
        newsydata(i,3)=data(i,3);
        newsydata(i,4)=data(i,4);
        newsydata(i,5)=data(i,5);
        
        flag=find(abs(lon_all(i,1)-ratio_time_doublet(:,1))==min(abs(lon_all(i,1)-ratio_time_doublet(:,1))));   
        tmp=find(abs(lat_all(i,1)-ratio_time_doublet(flag,2))==min(abs(lat_all(i,1)-ratio_time_doublet(flag,2))));
        location=flag(tmp);
        
        newsydata(i,6)=ratio_time_doublet(location,3);    
        fprintf(fid,'%s   %.2f   %.2f  %.2f  %d  %.2f\n',num2str(newsydata(i,1)),newsydata(i,2),newsydata(i,3),newsydata(i,4),newsydata(i,5),newsydata(i,6)); 
end
fclose(fid);
toc