#!/usr/bin/perl -w
$dir1 = "./STACK_60_200km_P";
$dir2 = "./STACK_60_200km_S";

@event = `ls -d $dir1/*.spe`;
$n=@event;
print "$n\n";

open(TM,"<filter_spectra") or die"can't open 'sta.dat' :$!";
@filter = <TM>;
close(TM);

$out = "Spectral_mean.dat";

open(OT,">$out");
foreach $_(@event){
    chomp($_);
    ($jk,$jk,$filename)=split("\/",$_);
    $file_dir1="$dir1/$filename";
    $file_dir2="$dir2/$filename";
    $filename1 =substr($filename,0,14);
    ($jk,$mag)=split(/\s+/,`/opt/soft/sac-101.6a/bin/saclst mag f $dir1/$filename`);

    $num=0;
foreach $_(@filter){
    chomp($_);
    ($fl,$fh)=split(" ",$_);

    $l1=`sacSpecmean -R$file_dir1 -D$fl/$fh`;
    chomp($l1);
    $mean_spectral_amplitude_P[$num]=sprintf("%.2f",$l1);

    $l2=`sacSpecmean -R$file_dir2 -D$fl/$fh`;
    chomp($l2);
    $mean_spectral_amplitude_S[$num]=sprintf("%.2f",$l2);

    print "$filename1\n";
    $num = $num+1;
}  
 print OT "$filename1  @mean_spectral_amplitude_P  @mean_spectral_amplitude_S  $mag\n";      
}
close(OT);

