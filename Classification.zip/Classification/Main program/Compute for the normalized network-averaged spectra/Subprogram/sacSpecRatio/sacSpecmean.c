#include <stdio.h>
#include <math.h>
#include <string.h>
#include "sac.h"

int main(int argc, char **argv) {
  char reference[128];
  SACHEAD hd;
  float f1,f2;
  float* ar;
  int i,j,k,n1,n2,error;
  float sumall,mean_value;
  error =0;
  
  /*input parameters*/
  for(i=1;!error && i<argc;i++ ){
    if(argv[i][0] == '-'){
    switch(argv[i][1]){
    case 'R':
    	sscanf(&argv[i][2],"%s",reference);
	break;
	
    case 'D':
    	sscanf(&argv[i][2],"%f/%f",&f1,&f2);
	break;
    default:
        error = 1;
	break;
    }
    }
  }

  if (argc < 2 || error){
     fprintf(stderr,"Usage:sacSpecRatio -Rspec.sac -Df1/f2 \nGot the weight of certain frequency\n");
     return 1;
  }

/*  tmark = -5; b */
  ar = read_sac(reference,&hd);
 
  n1 = rint(f1/hd.delta);
  n2 = rint(f2/hd.delta);

  sumall = 0.0;
  for(i=n1;i<n2;i++){
    sumall += ar[i];
  }
  mean_value= sumall/(n2-n1);    
  fprintf(stdout,"%.2f\n",mean_value);
  fclose(stdout);
}
