#include <stdio.h>
#include <math.h>
#include <string.h>
#include "sac.h"

int main(int argc, char **argv){
  char infile[128],outfile[128];
  SACHEAD hd;
  float tstart,tend,root,rms;
  float* ar;
  FILE *strm;
  char rdc;
  int i,j,tmark,error,nn,nrdc;
  error =0;
  rdc = 't';
  nrdc = -5;


  
  /*input parameters*/
  for(i=1;!error && i<argc;i++ ){
    if(argv[i][0] == '-'){
    switch(argv[i][1]){
    case 'E':
        rdc = argv[i][2];
	if (rdc == 't')sscanf(&argv[i][3],"%d",&nrdc);
	break;
/*
    case 'F':
    	sscanf(&argv[i][2],"%s",infile);
	break;
    case 'O':
        sscanf(&argv[i][2],"%s",outfile);
	break;
*/	
    case 'T':
    	sscanf(&argv[i][2],"%f/%f",&tstart,&tend);
	break;
    default:
        error = 1;
	break;
    }
    }
  }

  if (argc < 2 || error){
/*    
fprintf(stderr,"Usage:sacRMS -E[t(0-9,-5(b),-3(o),-2(a)] -Finfile -Ooutfile -Ttstart/tend\n");
*/
     fprintf(stderr,"Usage:sacRMS -E[t(0-9,-5(b),-3(o),-2(a)]  -Ttstart/tend sactraces ...\n");
return 1;
  }

/*  tmark = -5; b */
  for(i=1;i<argc;i++){
  tmark = nrdc;
  if(argv[i][0] == '-') continue;
  strcpy(infile,argv[i]);
  ar = read_sac2(infile,&hd,tmark,tstart,tend);
  nn = rint((tend-tstart)/hd.delta); //No include tend point
  hd.npts = nn;
  root = 0.0;
  for(j=0;j<hd.npts;j++){root += (ar[j]*ar[j])*pow(10,12);
  }
  rms = sqrt(root/hd.npts);
  printf("rms %f root %f\n",rms,root);
//  write_sac(outfile,hd,ar);
  }
}
