#!/usr/bin/perl -w

use Parallel::ForkManager;
$MAX_PROCESSES=12;
$pm = new Parallel::ForkManager($MAX_PROCESSES);

$dir = "/data/CC_new/Cut_Trace";
@stas = `ls -d $dir/*`;

open(JK,"<catalog");
@par = <JK>;
close(JK);

$file = "./STACK_60_200km_P";
if(-e $file){}else{`mkdir $file`;}
$file1 = "./STACK_60_200km_S";
if(-e $file1){}else{`mkdir $file1`;}

@Comp = ("BHZ","BHN","BHE");

$fl=1;
$fh=15;

foreach $_(@par){

    my $pid = $pm->start and next;

    chomp($_);
    ($filename,$evla,$evlo,$evmg,$evdp,$jk) = split(" ",$_);
      
    print "$filename\n";

    $num = 0;
    $num1 = 0;

if ($evmg<3) {

foreach $_(@stas){
    chomp($_);
    ($jk,$jk,$jk,$jk,$sta)=split("\/",$_);

foreach $_(@Comp){
    chomp($_);
    $comp=$_;

if ($sta ne "XYD") {

    $filename1="$filename.XJ.$sta.$comp";
    $filename2="$dir/$sta/$filename1";

if(-e $filename2){

    ($jk,$dist)=split(/\s+/,`saclst dist f $filename2`);

if($dist>=55 && $dist<=200) {
 
    open(SAC,"|sac>kk");   
    print SAC "r $filename2\n";
    print SAC "rmean\nrtr\ntaper\n";
    print SAC "bp c $fl $fh n 2 p 1\n";
    print SAC "w $file/$filename1\nq\n";
    close(SAC);

    $tb1 = 0; $te1 = 8;
    $tb2 = -12; $te2 = -4;
    $out1 = `sacRMS -Et1 -T$tb1/$te1 $file/$filename1`;
    $out2 = `sacRMS -Et1 -T$tb2/$te2 $file/$filename1`;
    ($jk,$rms1,$jk,$root1) = split(" ",$out1);
    ($jk,$rms2,$jk,$root2) = split(" ",$out2);
    if ($root1==0 || $root2==0) { 
    $snr =0;
    } else {
    $snr = sprintf("%.2f",$root1/$root2);
    }  

if($snr>=7) {

    ($jk11,$tp,$ts) = split(/\s+/,`saclst t1 t2 f $filename2`);
     
    $tb = $tp;
    $te = $tb+7;
    $pgname="$filename.XJ.$sta.$comp.pg";
    open(SAC,"|sac>kk");
    print SAC "cut $tb $te\n";
    print SAC "r $file/$filename1\n";
    print SAC "fft\n";
    print SAC "keepam\n";
    print SAC "ch t0 -12345\n";
    print SAC "w $file/$pgname\nq\n";
    close(SAC);

    open(SAC,"|sac > kk");
    print SAC "cut $fl $fh\n";
    print SAC "r $file/$pgname\n";
    print SAC "w over\n";
    print SAC "q\n";
    close(SAC);

    $tb0 = $ts;
    $te0 = $tb0+20;
    $sgname="$filename.XJ.$sta.$comp.sg";
    open(SAC,"|sac>kk");
    print SAC "cut $tb0 $te0\n";
    print SAC "r $file/$filename1\n";
    print SAC "fft\n";
    print SAC "keepam\n";
    print SAC "ch t0 -12345\n";
    print SAC "w $file1/$sgname\nq\n";
    close(SAC);

    open(SAC,"|sac > kk");
    print SAC "cut $fl $fh\n";
    print SAC "r $file1/$sgname\n";
    print SAC "w over\n";
    print SAC "q\n";
    close(SAC);

    `rm $file/$filename1`;

    ($jk,$depmax1)=split(/\s+/,`saclst depmax f $file/$pgname`);

    open(SAC,"|sac > kk");
    print SAC "r $file/$pgname\n";
    print SAC "div $depmax1\n";
    print SAC "w over\n";
    print SAC "q\n";
    close(SAC);

    open(SAC,"|sac > kk");
    print SAC "r $file1/$sgname\n";
    print SAC "div $depmax1\n";
    print SAC "w over\n";
    print SAC "q\n";
    close(SAC); 
         
    ($jk,$depmin,$depmax)=split(/\s+/,`saclst depmin depmax f $file/$pgname`);
    if ($depmin==0 && $depmax==0) {`rm $file/$pgname`;}

    ($jk,$depmin,$depmax)=split(/\s+/,`saclst depmin depmax f $file1/$sgname`);
    if ($depmin==0 && $depmax==0) {`rm $file1/$pgname`;}

    $FILE_PG="$file/$pgname";
    if(-e $FILE_PG) {
    $num = $num+1;
    }

    $FILE_SG="$file1/$sgname";
    if(-e $FILE_SG) {
    $num1 = $num1+1;
    }

    } elsif($snr<7) {
    `rm $file/$filename1`;
}
}
}
}
}
}
}
    if ($num>=3 && $num1>=3) {	
	$stack_sac_p="$filename.p.spe";
	$stack_sac_s="$filename.s.spe";
	`stacksac -Et-3 -N0 -M1 -O$stack_sac_p $file/$filename.*.pg`;
	`mv $stack_sac_p $file/$filename.spe`;
        `stacksac -Et-3 -N0 -M1 -O$stack_sac_s $file1/$filename.*.sg`;
	`mv $stack_sac_s $file1/$filename.spe`;

    $filenew1="$file/$filename.spe";
    open(SAC,"|sac>kk");
    print SAC "r $filenew1\n";
    print SAC "w over\n";
    print SAC "q\n";
    close(SAC);

    ($jk,$depmax0)=split(/\s+/,`saclst depmax f $filenew1`);

    open(SAC,"|sac > kk");
    print SAC "r $filenew1\n";
    print SAC "div $depmax0\n";
    print SAC "ch evla $evla evlo $evlo\n";
    print SAC "w over\n";
    print SAC "q\n";
    close(SAC);

    $filenew2="$file1/$filename.spe";
    open(SAC,"|sac > kk");
    print SAC "r $filenew2\n";
    print SAC "div $depmax0\n";
    print SAC "ch evla $evla evlo $evlo\n";
    print SAC "w over\n";
    print SAC "q\n";
    close(SAC);   
    }

    unlink "kk";
    $pm->finish;    
}

print "Waiting for Children...\n";
$pm->wait_all_children;
print "Everybody is out of the pool!\n";

`perl Make_spectra_mean.pl`;
