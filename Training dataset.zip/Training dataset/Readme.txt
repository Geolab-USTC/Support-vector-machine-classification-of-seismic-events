The three files ('Spectral_Nature', 'Spectral_Blast','Spectral_Induced') are training data for Tectonic Earthquakes,Quarry Blasts,and Induced earthquakes.
These files include the normalized network-averaged spectra of P and S waves in 27 frequency bands (27 AP (f) and 27 AS (f)), and the percentage of event daytime occurrence, D.

The three files ('P2S_amplitude_ratio_Nature','P2S_amplitude_ratio_Blast' and 'P2S_amplitude_ratio_Induced') are the amplitude ratio of AP(f)/AS(f) for Tectonic Earthquakes,Quarry Blasts,and Induced earthquakes.
When the signal-to-noise ratio (SNR) of a certain frequency band is not above 8, the value of amplitude ratio is set to 0, which is invalid information. 