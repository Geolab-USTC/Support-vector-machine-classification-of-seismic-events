The three files ('Spectral_Nature', 'Spectral_Blast','Spectral_Induced') are training data for Tectonic Earthquakes,Quarry Blasts,and Induced earthquakes.
Each line of the three files is discriminant features of one event, which include the normalized network-averaged spectra of P and S waves in 27 frequency bands (27 AP (f) and 27 AS (f)), and the percentage of event daytime occurrence, D.
The index of each line from 1 to 27 is the normalized network-averaged spectra of P, and from 28 to 54 is the normalized network-averaged spectra of S, 55 is the percentage of event daytime occurrence, D.

The three files ('P2S_amplitude_ratio_Nature','P2S_amplitude_ratio_Blast' and 'P2S_amplitude_ratio_Induced') are the amplitude ratios (AP(f)/AS(f)) for Tectonic Earthquakes,Quarry Blasts,and Induced earthquakes.
Each line of the three files is discriminant features of one event, which include the amplitude ratios in 27 frequency bands.
When the signal-to-noise ratio (SNR) of a certain frequency band is not above 7, the value of amplitude ratio is set to 0, which is invalid information. 

'filter_spectral' is the file mentioned above that contains 27 filter bands.